// ============================================
// Shared helpers: protect pages, render navbar state, logout.
// Include this AFTER api.js on every page.
// ============================================

// Redirects to login.html if not authenticated. Optionally enforce a role.
function requireAuth(requiredRole) {
  const user = Api.currentUser();
  if (!user || !Api.token()) {
    window.location.href = "login.html";
    return null;
  }
  if (requiredRole && user.role !== requiredRole) {
    window.location.href = user.role === "doctor" ? "doctor-dashboard.html" : "patient-dashboard.html";
    return null;
  }
  return user;
}

function logout() {
  Api.clearSession();
  window.location.href = "index.html";
}

// Fills in #navUserSlot on marketing pages with either Login/Register or a dashboard link.
function renderNavAuthState() {
  const slot = document.getElementById("navUserSlot");
  if (!slot) return;
  const user = Api.currentUser();

  if (user) {
    const dashboardHref = user.role === "doctor" ? "doctor-dashboard.html" : "patient-dashboard.html";
    slot.innerHTML = `
      <a href="${dashboardHref}" class="btn btn-outline btn-sm">Dashboard</a>
      <button class="btn btn-ghost btn-sm" onclick="logout()">Log out</button>
    `;
  } else {
    slot.innerHTML = `
      <a href="login.html" class="btn btn-ghost btn-sm">Login</a>
      <a href="register.html" class="btn btn-coral btn-sm">Sign up</a>
    `;
  }
}

function initials(name) {
  if (!name) return "?";
  return name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
}

function formatDate(d) {
  return new Date(d).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

document.addEventListener("DOMContentLoaded", renderNavAuthState);
